import { BrowserRouter as Router,Routes,Route } from "react-router-dom";
import Home from "./components/home";
import About from "./components/about";
import Services from "./components/services";
import Contact from "./components/contact";
import Header from "./components/header";
import Footer from "./components/footer";
function App() {
  return (
  <Router>
      <Header />
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/about" element={<div className="pt-5 mt-5"><About /></div>} />
      <Route path="/services" element={<Services />} />
      <Route path="/contact-us" element={<Contact />} />
    </Routes>
    <Footer />
  </Router>
     
  );
}

export default App;
